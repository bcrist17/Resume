﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System.Reflection;
using Website.Models;
using static System.Net.Mime.MediaTypeNames;

namespace Website.Managers
{
    public class MessagingManager
    {
        internal static JsonResult Login(string username, string password)
        {
            if (VerifyUser(username, password))
            {
                User user = PopulateUser(username);
                user.Username = username;
                return new JsonResult(new
                {
                    Message = "Correct",
                    Correct = true,
                    Url = "/Messaging/Chat",
                    Data = user
                });
            }
            else
            {
                return new JsonResult(new
                {
                    Message = "Invalid Username or password",
                    Correct = false
                });
            }
        }

        internal static void CreateUser(string username, string password)
        {
            //use this for creating an account
            //else if (username.Contains(" ") || password.Contains(" "))
            //{
            //    return new JsonResult(new
            //    {
            //        Message = "No spaces allowed",
            //        Correct = false
            //    });
            //}
            User user = new User();
            user.Username = username;
            PasswordHasher<string> passwordHasher = new PasswordHasher<string>();
            string hashed = passwordHasher.HashPassword(username, password);
            user.Password = hashed;
        }

        internal static User PopulateUser(string username)
        {
            User user = new User();
            //need to populate the user's messagse from the database
            return user;
        }

        internal static bool VerifyUser(string username, string password)
        {
            //Need to look into this
            User user = new User();
            PasswordHasher<string> passwordHasher = new PasswordHasher<string>();
            string hashed = passwordHasher.HashPassword(username, password);
            //need to get the saved password from the database
            //user.Password = "";
            //PasswordVerificationResult result = passwordHasher.VerifyHashedPassword(username, user.Password, password);
            PasswordVerificationResult result = passwordHasher.VerifyHashedPassword(username, "AQAAAAIAAYagAAAAEIv/JZY7MKGnARuZorpGckMfTbZQX6O/l7WW1K/1uPI4stUAy1OJN7JXCK6PQUFy+w==", password);
            if (result.ToString() == "Success") return true;
            return false;
        }
    }
}
