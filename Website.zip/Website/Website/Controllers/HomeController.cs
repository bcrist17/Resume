﻿using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using Website.Managers;


namespace WebApplication1.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        [Route("/")]
        [Route("/Home")]
        public IActionResult Info()
        {
            return View();
        }
        [Route("/Privacy")]
        [Route("/Home/Privacy")]
        public IActionResult Privacy()
        {
            return View();
        }
        
    }
}
