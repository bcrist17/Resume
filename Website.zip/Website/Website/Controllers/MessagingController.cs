﻿using Microsoft.AspNetCore.Mvc;
using Website.Managers;
using Website.Models;
using static System.Net.WebRequestMethods;

namespace Website.Controllers
{
    public class MessagingController : Controller
    {
        public IActionResult Login()
        {
            return View();
        }

        //Need to do this at home
        //[BasicAuthenticationAttribute("your-username", "your-password",
        //BasicRealm = "your-realm")]

        //Look at this too
        //https://johanbostrom.se/blog/adding-basic-auth-to-your-mvc-application-in-dotnet-core/
        public IActionResult Chat(User user) {
                return View(user);
        }

        //[HttpPost]
        //public JsonResult LoginCheck(string username, string password)
        //{
        //    return MessagingManager.Login(username, password);
        //}

        [HttpPost]
        public JsonResult LoginCheck(string username, string password)
        {
            return MessagingManager.Login(username, password);
        }
    }
}


// https://www.c-sharpcorner.com/article/how-to-create-login-page-in-asp-net-web-application-using-c-sharp-and-sql-server/
// https://www.c-sharpcorner.com/article/simple-login-application-using-Asp-Net-mvc/