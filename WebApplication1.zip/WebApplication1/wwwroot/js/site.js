﻿// Please see documentation at https://learn.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.
document.getElementById("darkMode").addEventListener("click", function () {
    $("body").toggleClass("dark-mode");
});


document.getElementById("Privacy-Page").addEventListener("click", function () {
    var url = "Home/Privacy";
    window.location.href = url;
    $.ajax({
        url: url,
        type: "GET",
        success: function (result) {
            $("#content").html(result);
        }
    });
});

document.getElementById("Home-Page").addEventListener("click", function () {
    var url = "Home";
    window.location.href = url;
    $.ajax({
        url: url,
        type: "GET",
        success: function (result) {
            $("#content").html(result);
        }
    });
});

document.getElementById("Messaging-Page").addEventListener("click", function () {
    //write code to call a function in the home controller that will take in a string and return true or false

    var url = "Home/Messaging";
    window.location.href = url;
    $.ajax({
        url: url,
        type: "GET",
        success: function (result) {
            $("#content").html(result);
        }
    });
});